"use strict";exports.id=2910,exports.ids=[2910],exports.modules={42910:(a,b,c)=>{c.d(b,{nJ:()=>o,NJ:()=>r,oh:()=>p,G6:()=>u,sm:()=>w,I8:()=>n,m1:()=>m,jX:()=>x,kB:()=>t});var d=c(87550),e=c.n(d),f=c(76760),g=c.n(f),h=c(73024),i=c.n(h),j=c(88189),k=c(73136);let l=function(){try{let a="file:///home/diegosouzapw/dev/proxys/9router/src/lib/db/migrationRunner.ts";if(a&&a.startsWith("file://")){let b=(0,k.fileURLToPath)(a);return g().join(g().dirname(b),"migrations")}}catch{}return g().join(process.cwd(),"src","lib","db","migrations")}(),m="object"==typeof globalThis.caches&&null!==globalThis.caches,n="phase-production-build"===process.env.NEXT_PHASE,o=(0,j._3)({isCloud:m});m||(0,j.sm)();let p=m?null:g().join(o,"storage.sqlite"),q=m?null:g().join(o,"db.json"),r=m?null:g().join(o,"db_backups");m||i().existsSync(o)||i().mkdirSync(o,{recursive:!0});let s=`
  CREATE TABLE IF NOT EXISTS provider_connections (
    id TEXT PRIMARY KEY,
    provider TEXT NOT NULL,
    auth_type TEXT,
    name TEXT,
    email TEXT,
    priority INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    access_token TEXT,
    refresh_token TEXT,
    expires_at TEXT,
    token_expires_at TEXT,
    scope TEXT,
    project_id TEXT,
    test_status TEXT,
    error_code TEXT,
    last_error TEXT,
    last_error_at TEXT,
    last_error_type TEXT,
    last_error_source TEXT,
    backoff_level INTEGER DEFAULT 0,
    rate_limited_until TEXT,
    health_check_interval INTEGER,
    last_health_check_at TEXT,
    last_tested TEXT,
    api_key TEXT,
    id_token TEXT,
    provider_specific_data TEXT,
    expires_in INTEGER,
    display_name TEXT,
    global_priority INTEGER,
    default_model TEXT,
    token_type TEXT,
    consecutive_use_count INTEGER DEFAULT 0,
    rate_limit_protection INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_pc_provider ON provider_connections(provider);
  CREATE INDEX IF NOT EXISTS idx_pc_active ON provider_connections(is_active);
  CREATE INDEX IF NOT EXISTS idx_pc_priority ON provider_connections(provider, priority);

  CREATE TABLE IF NOT EXISTS provider_nodes (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    name TEXT NOT NULL,
    prefix TEXT,
    api_type TEXT,
    base_url TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS key_value (
    namespace TEXT NOT NULL,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    PRIMARY KEY (namespace, key)
  );

  CREATE TABLE IF NOT EXISTS combos (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    data TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS api_keys (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    key TEXT NOT NULL UNIQUE,
    machine_id TEXT,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_ak_key ON api_keys(key);

  CREATE TABLE IF NOT EXISTS db_meta (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  CREATE TABLE IF NOT EXISTS usage_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    provider TEXT,
    model TEXT,
    connection_id TEXT,
    api_key_id TEXT,
    api_key_name TEXT,
    tokens_input INTEGER DEFAULT 0,
    tokens_output INTEGER DEFAULT 0,
    tokens_cache_read INTEGER DEFAULT 0,
    tokens_cache_creation INTEGER DEFAULT 0,
    tokens_reasoning INTEGER DEFAULT 0,
    status TEXT,
    timestamp TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_uh_timestamp ON usage_history(timestamp);
  CREATE INDEX IF NOT EXISTS idx_uh_provider ON usage_history(provider);
  CREATE INDEX IF NOT EXISTS idx_uh_model ON usage_history(model);

  CREATE TABLE IF NOT EXISTS call_logs (
    id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    method TEXT,
    path TEXT,
    status INTEGER,
    model TEXT,
    provider TEXT,
    account TEXT,
    connection_id TEXT,
    duration INTEGER DEFAULT 0,
    tokens_in INTEGER DEFAULT 0,
    tokens_out INTEGER DEFAULT 0,
    source_format TEXT,
    target_format TEXT,
    api_key_id TEXT,
    api_key_name TEXT,
    combo_name TEXT,
    request_body TEXT,
    response_body TEXT,
    error TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_cl_timestamp ON call_logs(timestamp);
  CREATE INDEX IF NOT EXISTS idx_cl_status ON call_logs(status);

  CREATE TABLE IF NOT EXISTS proxy_logs (
    id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    status TEXT,
    proxy_type TEXT,
    proxy_host TEXT,
    proxy_port INTEGER,
    level TEXT,
    level_id TEXT,
    provider TEXT,
    target_url TEXT,
    public_ip TEXT,
    latency_ms INTEGER DEFAULT 0,
    error TEXT,
    connection_id TEXT,
    combo_id TEXT,
    account TEXT,
    tls_fingerprint INTEGER DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_pl_timestamp ON proxy_logs(timestamp);
  CREATE INDEX IF NOT EXISTS idx_pl_status ON proxy_logs(status);
  CREATE INDEX IF NOT EXISTS idx_pl_provider ON proxy_logs(provider);

  -- Domain State Persistence (Phase 5)
  CREATE TABLE IF NOT EXISTS domain_fallback_chains (
    model TEXT PRIMARY KEY,
    chain TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS domain_budgets (
    api_key_id TEXT PRIMARY KEY,
    daily_limit_usd REAL NOT NULL,
    monthly_limit_usd REAL DEFAULT 0,
    warning_threshold REAL DEFAULT 0.8
  );

  CREATE TABLE IF NOT EXISTS domain_cost_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    api_key_id TEXT NOT NULL,
    cost REAL NOT NULL,
    timestamp INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_dch_key ON domain_cost_history(api_key_id);
  CREATE INDEX IF NOT EXISTS idx_dch_ts ON domain_cost_history(timestamp);

  CREATE TABLE IF NOT EXISTS domain_lockout_state (
    identifier TEXT PRIMARY KEY,
    attempts TEXT NOT NULL,
    locked_until INTEGER
  );

  CREATE TABLE IF NOT EXISTS domain_circuit_breakers (
    name TEXT PRIMARY KEY,
    state TEXT NOT NULL DEFAULT 'CLOSED',
    failure_count INTEGER DEFAULT 0,
    last_failure_time INTEGER,
    options TEXT
  );

  CREATE TABLE IF NOT EXISTS semantic_cache (
    id TEXT PRIMARY KEY,
    signature TEXT NOT NULL UNIQUE,
    model TEXT NOT NULL,
    prompt_hash TEXT NOT NULL,
    response TEXT NOT NULL,
    tokens_saved INTEGER DEFAULT 0,
    hit_count INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_sc_sig ON semantic_cache(signature);
  CREATE INDEX IF NOT EXISTS idx_sc_model ON semantic_cache(model);
`;function t(a){if(!a)return null;let b={};for(let[c,d]of Object.entries(a)){let a=c.replace(/_([a-z])/g,(a,b)=>b.toUpperCase());if("isActive"===a||"rateLimitProtection"===a)b[a]=1===d||!0===d;else if("providerSpecificData"===a&&"string"==typeof d)try{b[a]=JSON.parse(d)}catch{b[a]=d}else b[a]=d}return b}function u(a){let b={};for(let[c,d]of Object.entries(a))null!=d&&(b[c]=d);return b}let v=null;function w(){if(v)return v;if(m||n)return n&&console.log("[DB] Build phase detected — using in-memory SQLite (read-only)"),(v=new(e())(":memory:")).pragma("journal_mode = WAL"),v.exec(s),v;if(i().existsSync(p))try{let a=new(e())(p,{readonly:!0}),b=a.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='schema_migrations'").get();if(a.close(),b){let a=p+".old-schema";for(let b of(console.log(`[DB] Old incompatible schema detected — renaming to ${g().basename(a)}`),i().renameSync(p,a),["-wal","-shm"]))try{i().existsSync(p+b)&&i().unlinkSync(p+b)}catch{}}}catch(a){console.warn("[DB] Could not probe existing DB, will create fresh:",a.message);try{i().unlinkSync(p)}catch{}}(v=new(e())(p)).pragma("journal_mode = WAL"),v.pragma("busy_timeout = 5000"),v.pragma("synchronous = NORMAL"),v.exec(s);var a=v;try{let b=a.prepare("PRAGMA table_info(provider_connections)").all();new Set(b.map(a=>a.name)).has("rate_limit_protection")||(a.exec("ALTER TABLE provider_connections ADD COLUMN rate_limit_protection INTEGER DEFAULT 0"),console.log("[DB] Added provider_connections.rate_limit_protection column"))}catch(a){console.warn("[DB] Failed to verify provider_connections schema:",a.message)}return v.exec(`
    CREATE TABLE IF NOT EXISTS _omniroute_migrations (
      version TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    INSERT OR IGNORE INTO _omniroute_migrations (version, name)
    VALUES ('001', 'initial_schema');
  `),!function(a){a.exec(`
    CREATE TABLE IF NOT EXISTS _omniroute_migrations (
      version TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);let b=i().existsSync(l)?i().readdirSync(l).filter(a=>a.endsWith(".sql")).sort().map(a=>{let b=a.match(/^(\d+)_(.+)\.sql$/);return b?{version:b[1],name:b[2],path:g().join(l,a)}:null}).filter(Boolean):[],c=new Set(a.prepare("SELECT version FROM _omniroute_migrations").all().map(a=>a.version)),d=0;for(let e of b){if(c.has(e.version))continue;let b=i().readFileSync(e.path,"utf-8"),f=a.transaction(()=>{a.exec(b),a.prepare("INSERT INTO _omniroute_migrations (version, name) VALUES (?, ?)").run(e.version,e.name)});try{f(),d++,console.log(`[Migration] Applied: ${e.version}_${e.name}`)}catch(b){let a=b instanceof Error?b.message:String(b);throw console.error(`[Migration] FAILED: ${e.version}_${e.name} — ${a}`),b}}d>0&&console.log(`[Migration] ${d} migration(s) applied successfully.`)}(v),q&&i().existsSync(q)&&function(a,b){try{let c=i().readFileSync(b,"utf-8"),d=JSON.parse(c),e=(d.providerConnections||[]).length,f=(d.providerNodes||[]).length,h=(d.apiKeys||[]).length;if(0===e&&0===f&&0===h){console.log("[DB] db.json has no data to migrate, skipping"),i().renameSync(b,b+".empty");return}console.log(`[DB] Migrating db.json → SQLite (${e} connections, ${f} nodes, ${h} keys)...`),a.transaction(()=>{let b=a.prepare(`
        INSERT OR REPLACE INTO provider_connections (
          id, provider, auth_type, name, email, priority, is_active,
          access_token, refresh_token, expires_at, token_expires_at,
          scope, project_id, test_status, error_code, last_error,
          last_error_at, last_error_type, last_error_source, backoff_level,
          rate_limited_until, health_check_interval, last_health_check_at,
          last_tested, api_key, id_token, provider_specific_data,
          expires_in, display_name, global_priority, default_model,
          token_type, consecutive_use_count, rate_limit_protection, created_at, updated_at
        ) VALUES (
          @id, @provider, @authType, @name, @email, @priority, @isActive,
          @accessToken, @refreshToken, @expiresAt, @tokenExpiresAt,
          @scope, @projectId, @testStatus, @errorCode, @lastError,
          @lastErrorAt, @lastErrorType, @lastErrorSource, @backoffLevel,
          @rateLimitedUntil, @healthCheckInterval, @lastHealthCheckAt,
          @lastTested, @apiKey, @idToken, @providerSpecificData,
          @expiresIn, @displayName, @globalPriority, @defaultModel,
          @tokenType, @consecutiveUseCount, @rateLimitProtection, @createdAt, @updatedAt
        )
      `);for(let a of d.providerConnections||[])b.run({id:a.id,provider:a.provider,authType:a.authType||"oauth",name:a.name||null,email:a.email||null,priority:a.priority||0,isActive:+(!1!==a.isActive),accessToken:a.accessToken||null,refreshToken:a.refreshToken||null,expiresAt:a.expiresAt||null,tokenExpiresAt:a.tokenExpiresAt||null,scope:a.scope||null,projectId:a.projectId||null,testStatus:a.testStatus||null,errorCode:a.errorCode||null,lastError:a.lastError||null,lastErrorAt:a.lastErrorAt||null,lastErrorType:a.lastErrorType||null,lastErrorSource:a.lastErrorSource||null,backoffLevel:a.backoffLevel||0,rateLimitedUntil:a.rateLimitedUntil||null,healthCheckInterval:a.healthCheckInterval||null,lastHealthCheckAt:a.lastHealthCheckAt||null,lastTested:a.lastTested||null,apiKey:a.apiKey||null,idToken:a.idToken||null,providerSpecificData:a.providerSpecificData?JSON.stringify(a.providerSpecificData):null,expiresIn:a.expiresIn||null,displayName:a.displayName||null,globalPriority:a.globalPriority||null,defaultModel:a.defaultModel||null,tokenType:a.tokenType||null,consecutiveUseCount:a.consecutiveUseCount||0,rateLimitProtection:+(!0===a.rateLimitProtection||1===a.rateLimitProtection),createdAt:a.createdAt||new Date().toISOString(),updatedAt:a.updatedAt||new Date().toISOString()});let c=a.prepare(`
        INSERT OR REPLACE INTO provider_nodes (id, type, name, prefix, api_type, base_url, created_at, updated_at)
        VALUES (@id, @type, @name, @prefix, @apiType, @baseUrl, @createdAt, @updatedAt)
      `);for(let a of d.providerNodes||[])c.run({id:a.id,type:a.type,name:a.name,prefix:a.prefix||null,apiType:a.apiType||null,baseUrl:a.baseUrl||null,createdAt:a.createdAt||new Date().toISOString(),updatedAt:a.updatedAt||new Date().toISOString()});let e=a.prepare("INSERT OR REPLACE INTO key_value (namespace, key, value) VALUES (?, ?, ?)");for(let[a,b]of Object.entries(d.modelAliases||{}))e.run("modelAliases",a,JSON.stringify(b));for(let[a,b]of Object.entries(d.mitmAlias||{}))e.run("mitmAlias",a,JSON.stringify(b));for(let[a,b]of Object.entries(d.settings||{}))e.run("settings",a,JSON.stringify(b));for(let[a,b]of Object.entries(d.pricing||{}))e.run("pricing",a,JSON.stringify(b));for(let[a,b]of Object.entries(d.customModels||{}))e.run("customModels",a,JSON.stringify(b));d.proxyConfig&&(e.run("proxyConfig","global",JSON.stringify(d.proxyConfig.global||null)),e.run("proxyConfig","providers",JSON.stringify(d.proxyConfig.providers||{})),e.run("proxyConfig","combos",JSON.stringify(d.proxyConfig.combos||{})),e.run("proxyConfig","keys",JSON.stringify(d.proxyConfig.keys||{})));let f=a.prepare(`
        INSERT OR REPLACE INTO combos (id, name, data, created_at, updated_at)
        VALUES (@id, @name, @data, @createdAt, @updatedAt)
      `);for(let a of d.combos||[])f.run({id:a.id,name:a.name,data:JSON.stringify(a),createdAt:a.createdAt||new Date().toISOString(),updatedAt:a.updatedAt||new Date().toISOString()});let g=a.prepare(`
        INSERT OR REPLACE INTO api_keys (id, name, key, machine_id, created_at)
        VALUES (@id, @name, @key, @machineId, @createdAt)
      `);for(let a of d.apiKeys||[])g.run({id:a.id,name:a.name,key:a.key,machineId:a.machineId||null,createdAt:a.createdAt||new Date().toISOString()})})();let j=b+".migrated";i().renameSync(b,j),console.log(`[DB] ✓ Migration complete. Original saved as ${j}`);let k=g().join(o,"db_backups");if(i().existsSync(k)){let a=i().readdirSync(k).filter(a=>a.endsWith(".json"));a.length>0&&console.log(`[DB] Note: ${a.length} legacy .json backups remain in ${k}`)}}catch(a){console.error("[DB] Migration from db.json failed:",a.message)}}(v,q),v.prepare("INSERT OR REPLACE INTO db_meta (key, value) VALUES ('schema_version', '1')").run(),console.log(`[DB] SQLite database ready: ${p}`),v}function x(){v&&(v.close(),v=null)}},88189:(a,b,c)=>{c.d(b,{_3:()=>l,sm:()=>k,ys:()=>m});var d=c(76760),e=c.n(d),f=c(48161),g=c.n(f);let h="omniroute";function i(){try{return g().homedir()}catch{return process.cwd()}}function j(a){if("string"!=typeof a)return null;let b=a.trim();return b?e().resolve(b):null}function k(){return e().join(i(),`.${h}`)}function l({isCloud:a=!1}={}){if(a)return"/tmp";let b=j(process.env.DATA_DIR);if(b)return b;let c=i();if("win32"===process.platform){let a=process.env.APPDATA||e().join(c,"AppData","Roaming");return e().join(a,h)}let d=j(process.env.XDG_CONFIG_HOME);return d?e().join(d,h):k()}function m(a,b){if(!a||!b)return!1;let c=e().resolve(a),d=e().resolve(b);return"win32"===process.platform?c.toLowerCase()===d.toLowerCase():c===d}}};